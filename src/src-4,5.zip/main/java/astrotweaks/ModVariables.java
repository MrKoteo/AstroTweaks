package astrotweaks;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.common.MinecraftForge;


import net.minecraft.world.World;
import net.minecraft.client.Minecraft;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.Biome;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;



public class ModVariables {
	public ModVariables() {}

	public static boolean Enable_SnowVillages = true;
	public static boolean Enable_ForestVillages = true;
	//public static boolean Enable_BirchVillages = true;

	public static boolean Enable_Ground_Elements = true;
	public static double Stick_Gen_Attempts = 2.0;
	public static double Rock_Gen_Attempts = 0.2;
	public static int Stick_Gen_Min_Y = 60;
	public static int Stick_Gen_Max_Y = 120;
	public static int Rock_Gen_Min_Y = 55;
	public static int Rock_Gen_Max_Y = 130;
	public static Set<ResourceLocation> Stick_Gen_Biomes = null;
	public static Set<ResourceLocation> Rock_Gen_Biomes  = null;

	public static boolean Overworld_Minerals_Generation = true;
	
	
	public void preInit(FMLPreInitializationEvent event) {
		MinecraftForge.EVENT_BUS.register(this);

	}


}
