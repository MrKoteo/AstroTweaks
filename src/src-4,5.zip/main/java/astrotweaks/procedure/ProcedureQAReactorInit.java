package astrotweaks.procedure;

import java.util.Map;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureQAReactorInit extends ElementsAstrotweaksMod.ModElement {
	public ProcedureQAReactorInit(ElementsAstrotweaksMod instance) {
		super(instance, 496);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
