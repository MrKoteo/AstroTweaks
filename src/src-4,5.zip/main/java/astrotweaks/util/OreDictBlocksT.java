package astrotweaks.oredict;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraft.item.ItemStack;

import astrotweaks.block.*;



import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictBlocksT extends ElementsAstrotweaksMod.ModElement {
	public OreDictBlocksT(ElementsAstrotweaksMod instance) {
		super(instance, 514);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("blockRuby", new ItemStack(BlockRubyBlock.block, (int) (1)));
		OreDictionary.registerOre("blockBrass", new ItemStack(BlockBrassBlock.block, (int) (1)));

		OreDictionary.registerOre("stone", new ItemStack(BlockDeepslate.block, (int) (1)));
		OreDictionary.registerOre("cobblestone", new ItemStack(BlockCobbledDeepslate.block, (int) (1)));

		OreDictionary.registerOre("dirt", new ItemStack(BlockDirtBricks.block, (int) (1)));

		//OreDictionary.registerOre("cobblestoneSlab", new ItemStack(BlockCobbledDeepslateSlab.block, (int) (1)));
	}
}
