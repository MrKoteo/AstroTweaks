package astrotweaks.world;

import java.util.Random;
import java.util.Set;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;

import astrotweaks.AstrotweaksModVariables;
import astrotweaks.ModVariables;


public final class SurfaceWorldGenerator {
	private SurfaceWorldGenerator() {}
	/**
	* Attempts to place blocks on the surface within the chunk.
	*
	* @param rand Random - source of randomness
	* @param chunkXorBase chunkX: can be chunk index (x) *or* block coordinate; the function does not multiply itself
	* @param chunkZorBase chunkZ: similarly for Z
	* @param world world
	* @param block block to set (not null)
	* @param allowedBiomes ResourceLocation set of allowed biomes (e.g. "plains")
	* @param attempts number of attempts per chunk (e.g. 5)
	* @param minY minimum Y for searching surface (e.g. 50)
	* @param maxY maximum Y for searching surface (e.g. 150)
	* @param coordsAreChunkCoords if true - chunkXorBase and chunkZorBase are chunk indices and will be multiplied by 16;
	* if false - block coordinates of the chunk base are considered (usually baseX/baseZ)
	*/

    // Blocks on which decoration CANNOT be placed
    private static final Set<Block> FORBIDDEN_BLOCKS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        Blocks.COBBLESTONE,
        Blocks.PLANKS,
        Blocks.RED_MUSHROOM_BLOCK,
        Blocks.BROWN_MUSHROOM_BLOCK
        // forbidden
    ))); 

	private static final Set<ResourceLocation> DEFAULT_BIOMES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
		new ResourceLocation("plains"),new ResourceLocation("forest"),new ResourceLocation("taiga"),new ResourceLocation("swampland"),new ResourceLocation("forest_hills"),
		new ResourceLocation("taiga_hills"),new ResourceLocation("jungle"),new ResourceLocation("jungle_hills"),new ResourceLocation("jungle_edge"),
		new ResourceLocation("birch_forest"),new ResourceLocation("birch_forest_hills"),new ResourceLocation("roofed_forest"),new ResourceLocation("redwood_taiga"),
		new ResourceLocation("redwood_taiga_hills"),new ResourceLocation("savanna"),new ResourceLocation("river"),new ResourceLocation("smaller_extreme_hills"),
		new ResourceLocation("extreme_hills_with_trees"),new ResourceLocation("savanna_rock")
	)));


	public static void generateSurface(Random rand, int chunkX, int chunkZ, World world, Block block, Set<ResourceLocation> allowedBiomes, double gen_attempts, int minY, int maxY) {
		try {
			if (world == null || block == null) return;
			if (allowedBiomes == null) {allowedBiomes = DEFAULT_BIOMES;}
			if (gen_attempts <= 0) return;
			if (gen_attempts > 999) gen_attempts = 999;
			if (minY < 0) minY = 4; // 4
			if (maxY > 255) maxY = 250; // max Y scan Pos
			if (minY > maxY) return;
		} catch (Exception e) {
			System.out.println("Error init AstroTweaks World Decorator! Please, edit mod config.");
		}

	
	    int attempts; // check attempts
	    if (gen_attempts < 1.0) {
	        if (rand.nextFloat() >= gen_attempts) return;
	        attempts = 1;
	    } else {
	        int guaranteed = (int) gen_attempts;
	        double fractional = gen_attempts - guaranteed;
	        attempts = guaranteed;
	        if (fractional > 0.0 && rand.nextDouble() < fractional) {
	            attempts++;
	        }
	    }



		// biome check at chunk center
        Biome centerBiome = world.getBiome(new BlockPos(chunkX + 8, 64, chunkZ + 8));
		ResourceLocation biomeName = Biome.REGISTRY.getNameForObject(centerBiome);
		if (biomeName == null || !allowedBiomes.contains(biomeName)) return;


		final int dvt = 1; // Border outline of Chunk

		for (int i = 0; i < attempts; i++) {
            int x = chunkX + dvt + rand.nextInt(16 - dvt * 2);
            int z = chunkZ + dvt + rand.nextInt(16 - dvt * 2);

			// find Y up Solid block in HEIGHT_LINE
			int topY = world.getHeight(x, z);
			BlockPos probe = new BlockPos(x, topY - 1, z);
            IBlockState probeState = world.getBlockState(probe);

            while (probe.getY() > minY && (world.isAirBlock(probe) || isLeavesBlock(probeState) || isLogBlock(probeState))) {
                probe = probe.down();
                probeState = world.getBlockState(probe);
            }
			
            int surfaceY = probe.getY();
            if (surfaceY < minY || surfaceY > maxY) continue;

            // Check surface block is valid
            Block groundBlock = probeState.getBlock();
            boolean baseIsSolid = probeState.isSideSolid(world, probe, EnumFacing.UP) && probeState.isOpaqueCube() && probeState.isFullCube();
            if (!baseIsSolid) continue;
            if (FORBIDDEN_BLOCKS.contains(groundBlock)) continue;


			BlockPos placePos = probe.up(); // valid block above ground
            if (placePos.getY() < 0 || placePos.getY() > 255) continue;

            IBlockState placeState = world.getBlockState(placePos);
			Block placeBlock = placeState.getBlock();
			// Checking that the place can be replaced: air or replaceable blocks, but NOT grass/foliage/stems, etc.
			boolean placeIsReplaceable = (world.isAirBlock(placePos) || placeState.getMaterial().isReplaceable()) && placeBlock != Blocks.DOUBLE_PLANT || isLeavesBlock(placeState);

			if (!placeIsReplaceable) continue;
			if (placeBlock == block) continue;


			// place Element
			world.setBlockState(placePos, block.getDefaultState(), 2);
		}
	}

	
	private static boolean isLeavesBlock(IBlockState state) {
		if (state == null) return false;
		Block b = state.getBlock();
		// In Minecraft 1.12 foliage - Blocks.LEAVES and Blocks.LEAVES2,
		// mods can also add their own leaves - you can check the material
		return b == Blocks.LEAVES || b == Blocks.LEAVES2 || state.getMaterial() == net.minecraft.block.material.Material.LEAVES;
	}
    private static boolean isLogBlock(IBlockState state) {
        if (state == null) return false;
        Block b = state.getBlock();
        return b == Blocks.LOG || b == Blocks.LOG2;
    }
	
}
