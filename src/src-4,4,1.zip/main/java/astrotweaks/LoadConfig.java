package astrotweaks.util;

import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.FMLLog;

import java.io.File;

import astrotweaks.AstrotweaksModVariables;
//import astrotweaks.ElementsAstrotweaksMod;


//@ElementsAstrotweaksMod.ModElement.Tag
public class LoadConfig/* extends ElementsAstrotweaksMod.ModElement */{
	private static final org.apache.logging.log4j.Logger LOGGER = FMLLog.getLogger();
	
	public LoadConfig(/*ElementsAstrotweaksMod instance*/) {
		//super(instance, 500);
	}

	//@Override
	public void preInit(FMLPreInitializationEvent event) {
		MinecraftForge.EVENT_BUS.register(this);

		//System.out.println("abobba 1");

		Configuration config = new Configuration(event.getSuggestedConfigurationFile());
		try {
			config.load();

			// Boolean with safe fallback
			AstrotweaksModVariables.AstroTech_Environment = safeGetBoolean(config, "AstroTech_Environment", "Astro_Tech", false, "AstroTech Environment (y/n)");
			AstrotweaksModVariables.EnableProgressionSystem = safeGetBoolean(config, "EnableProgressionSystem", "Astro_Tech", false, "Enable Progression System (y/n)");

			AstrotweaksModVariables.Overworld_Quartz_Generation = safeGetBoolean(config, "Overworld_Quartz_Generation", "generation", true, "Enable Overworld Quartz Generation (y/n)");
			AstrotweaksModVariables.Ruby_Generation = safeGetBoolean(config, "Ruby_Generation", "generation", true, "Enable Ruby Generation (y/n)");
			AstrotweaksModVariables.Overworld_Minerals_Generation = safeGetBoolean(config, "Overworld_Minerals_Generation", "generation", true, "Enable Overworld Minerals Generation (y/n)");
			AstrotweaksModVariables.Enable_SnowVillages = safeGetBoolean(config, "Enable_SnowVillages", "generation", true, "Enable Snow Villages generation (y/n)");
			AstrotweaksModVariables.Enable_Ground_Elements = safeGetBoolean(config, "Enable_Ground_Elements", "generation", true, "Enable Ground elements generation (y/n)");
			// Double values with validation of range and parsing
			AstrotweaksModVariables.Stick_Gen_Attempts = safeGetDouble(config, "Stick_Gen_Attempts", "generation", 2.0 /*def*/, 0.0 /*min*/, 1000.0 /*max*/, "Number of attempts to generate an element (double num) [default: 2.0]");
			AstrotweaksModVariables.Rock_Gen_Attempts = safeGetDouble(config, "Rock_Gen_Attempts", "generation", 0.2 /*def*/, 0.0 /*min*/, 1000.0 /*max*/, "Number of attempts to generate an element (double num) [default: 0.2]");

			AstrotweaksModVariables.Money_Can_Smelt = safeGetBoolean(config, "Money_Can_Smelt", "misc", true, "Can coins be melted down (y/n)");
			AstrotweaksModVariables.Money_Can_Craft = safeGetBoolean(config, "Money_Can_Craft", "misc", true, "Can copper coins be crafted at the MoneyTable from a copper plate (y/n)");
			AstrotweaksModVariables.Food_Negative_Effects = safeGetBoolean(config, "Food_Negative_Effects", "misc", true, "Will poisonous food have more violent effects? (y/n)");

			AstrotweaksModVariables.Enable_Depths_Dimension = safeGetBoolean(config, "Enable_Depths_Dimension", "world", true, "Should register Depths dimension? (y/n)");
			AstrotweaksModVariables.Enable_Depths_Dim_Bedrock_TP = safeGetBoolean(config, "Enable_Depths_Dim_Bedrock_TP", "world", true, "Allow access to the Depths via Bedrock? (y/n)");

		} finally {
			if (config.hasChanged()) {
				config.save();
			}
		}
	}

	// --- helper methods ---

	private boolean safeGetBoolean(Configuration config, String name, String category, boolean def, String comment) {
		try {
			// read as string first to detect malformed booleans like "yes" or "tru"
			String raw = config.get(category, name, Boolean.toString(def), comment).getString();
			// allow "true"/"false" (case-insensitive), also support "1"/"0" as convenience
			if (raw.equalsIgnoreCase("true") || raw.equals("1")) {
				return true;
			} else if (raw.equalsIgnoreCase("false") || raw.equals("0")) {
				return false;
			} else {
				LOGGER.warn("Config '{}' in category '{}' has invalid boolean value '{}'. Using default: {}", name, category, raw, def);
				// overwrite invalid value with default so it is saved back
				config.get(category, name, def).set(def);
				return def;
			}
		} catch (Exception e) {
			LOGGER.error("Error reading boolean config '{}.{}': {}", category, name, e.getMessage());
			config.get(category, name, def).set(def);
			return def;
		}
	}

	private double safeGetDouble(Configuration config, String name, String category, double def, double min, double max, String comment) {
		try {
			String raw = config.get(category, name, Double.toString(def), comment).getString();
			double val;
			try {
				val = Double.parseDouble(raw);
			} catch (NumberFormatException nfe) {
				LOGGER.warn("Config '{}' in category '{}' has invalid double value '{}'. Using default: {}", name, category, raw, def);
				config.get(category, name, def).set(def);
				return def;
			}
			if (val < min || val > max) {
				LOGGER.warn("Config '{}' in category '{}' out of range ({}-{}): {}. Using default: {}", name, category, min, max, val, def);
				config.get(category, name, def).set(def);
				return def;
			}
			return val;
		} catch (Exception e) {
			LOGGER.error("Error reading double config '{}.{}': {}", category, name, e.getMessage());
			config.get(category, name, def).set(def);
			return def;
		}
	}
}
