package astrotweaks.recipe;


import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.registries.IForgeRegistryEntry;


public class DeepslateSlabsRecipes {

    /**
     *
     * @param inputItem   Item | Block input
     * @param slabOutput  Item result
     * @param outputCount
     */
    public static void registerSlabRecipe(Item inputItem, Item slabOutput, int outputCount) {
        if (inputItem == null || slabOutput == null) return;

        ItemStack inputStack = new ItemStack(inputItem);
        ItemStack resultStack = new ItemStack(slabOutput, outputCount);

        // Pattern: "###"
        // Format GameRegistry.addShapedRecipe: (ResourceLocation name, Object[] recipe)

        ResourceLocation name = new ResourceLocation("astrotweaks", slabOutput.getRegistryName().getResourcePath() + "_from_" + inputItem.getRegistryName().getResourcePath());
        GameRegistry.addShapedRecipe(name, null, resultStack,
                "###",
                '#', inputStack
        );
    }


    public static void registerAllSlabs() {

        registerSlabRecipe(Item.REGISTRY.getObject(new ResourceLocation("astrotweaks", "cobbled_deepslate")), Item.REGISTRY.getObject(new ResourceLocation("astrotweaks", "cobbled_deepslate_slab")), 6);
        registerSlabRecipe(Item.REGISTRY.getObject(new ResourceLocation("astrotweaks", "deepslate_bricks")), Item.REGISTRY.getObject(new ResourceLocation("astrotweaks", "deepslate_bricks_slab")), 6);
        registerSlabRecipe(Item.REGISTRY.getObject(new ResourceLocation("astrotweaks", "deepslate_tiles")), Item.REGISTRY.getObject(new ResourceLocation("astrotweaks", "deepslate_tiles_slab")), 6);
    }
}
