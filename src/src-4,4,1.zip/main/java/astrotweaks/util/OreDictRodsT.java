
package astrotweaks.oredict;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.*;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodsT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodsT(ElementsAstrotweaksMod instance) {
		super(instance, 486);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodIron", new ItemStack(ItemIronStick.block, (int) (1)));
		OreDictionary.registerOre("rodGold", new ItemStack(ItemGoldStick.block, (int) (1)));
		OreDictionary.registerOre("rodCopper", new ItemStack(ItemCopperStick.block, (int) (1)));
		OreDictionary.registerOre("rodTin", new ItemStack(ItemTinStick.block, (int) (1)));
		OreDictionary.registerOre("rodBronze", new ItemStack(ItemBronzeStick.block, (int) (1)));
		OreDictionary.registerOre("rodDiamond", new ItemStack(ItemDiamondStick.block, (int) (1)));
	    OreDictionary.registerOre("rodAluminium", new ItemStack(ItemAluminiumStick.block, (int) (1)));
	    OreDictionary.registerOre("rodTitanium", new ItemStack(ItemTitaniumStick.block, (int) (1)));
	    OreDictionary.registerOre("rodNickel", new ItemStack(ItemNickelStick.block, (int) (1)));
	    OreDictionary.registerOre("rodCobalt", new ItemStack(ItemCobaltStick.block, (int) (1)));
	    OreDictionary.registerOre("rodMeteoricIron", new ItemStack(ItemMeteoricStick.block, (int) (1)));
	    OreDictionary.registerOre("rodElectrum", new ItemStack(ItemElectrumStick.block, (int) (1)));
	    OreDictionary.registerOre("rodEmerald", new ItemStack(ItemEmeraldStick.block, (int) (1)));
	    OreDictionary.registerOre("rodRuby", new ItemStack(ItemRubyStick.block, (int) (1)));
	    OreDictionary.registerOre("rodSteel", new ItemStack(ItemSteelStick.block, (int) (1)));
	    OreDictionary.registerOre("rodIridium", new ItemStack(ItemIridiumStick.block, (int) (1)));
	    OreDictionary.registerOre("rodSilver", new ItemStack(ItemSilverStick.block, (int) (1)));
	    OreDictionary.registerOre("rodUranium", new ItemStack(ItemUraniumStick.block, (int) (1)));
	    OreDictionary.registerOre("rodBrass", new ItemStack(ItemBrassStick.block, (int) (1)));
		
	}
}
