
package astrotweaks.oredict;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemBrassNugget;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictNuggetsT extends ElementsAstrotweaksMod.ModElement {
	public OreDictNuggetsT(ElementsAstrotweaksMod instance) {
		super(instance, 553);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("nuggetBrass", new ItemStack(ItemBrassNugget.block, (int) (1)));
	}
}
