
package astrotweaks.oredict;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemRuby;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictGemsT extends ElementsAstrotweaksMod.ModElement {
	public OreDictGemsT(ElementsAstrotweaksMod instance) {
		super(instance, 482);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("gemRuby", new ItemStack(ItemRuby.block, (int) (1)));
	}
}
