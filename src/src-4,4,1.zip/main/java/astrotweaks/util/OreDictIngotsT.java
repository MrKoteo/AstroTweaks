
package astrotweaks.oredict;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemBrassIngot;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictIngotsT extends ElementsAstrotweaksMod.ModElement {
	public OreDictIngotsT(ElementsAstrotweaksMod instance) {
		super(instance, 551);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("ingotBrass", new ItemStack(ItemBrassIngot.block, (int) (1)));
	}
}
