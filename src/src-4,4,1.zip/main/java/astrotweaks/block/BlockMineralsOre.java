package astrotweaks.block;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.oredict.OreDictionary;

import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.World;
import net.minecraft.world.IBlockAccess;
import net.minecraft.util.math.BlockPos;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.init.Blocks;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.Block;
import net.minecraft.util.NonNullList;


import javax.annotation.Nullable;

import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Random;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

import astrotweaks.AstrotweaksModVariables;
import astrotweaks.creativetab.TabAstroTweaks;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class BlockMineralsOre extends ElementsAstrotweaksMod.ModElement {
	@GameRegistry.ObjectHolder("astrotweaks:minerals_ore")
	public static final Block block = null;
	public BlockMineralsOre(ElementsAstrotweaksMod instance) {
		super(instance, 714);
	}

	@Override
	public void initElements() {
		elements.blocks.add(() -> new BlockCustom().setRegistryName("minerals_ore"));
		elements.items.add(() -> new ItemBlock(block).setRegistryName(block.getRegistryName()));
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(block), 0, new ModelResourceLocation("astrotweaks:minerals_ore", "inventory"));
	}
	
/*
	@Override
	public void generateWorld(Random random, int chunkX, int chunkZ, World world, int dimID, IChunkGenerator cg, IChunkProvider cp) {
	    if (dimID != 0) return;
	    if (!AstrotweaksModVariables.Overworld_Minerals_Generation) return;
	
	    Predicate<IBlockState> match = blockAt -> blockAt != null && blockAt.getBlock() == Blocks.STONE;
	
	    for (int i = 0; i < 6; i++) {
	        int x = chunkX + random.nextInt(16);
	        int y = random.nextInt(43) + 2;
	        int z = chunkZ + random.nextInt(16);
	
	        new WorldGenMinable(block.getDefaultState(), 6, (com.google.common.base.Predicate<IBlockState>) match::test)
	                .generate(world, random, new BlockPos(x, y, z));
	    }
	}
*/



	@Override
	public void generateWorld(Random random, int chunkX, int chunkZ, World world, int dimID, IChunkGenerator cg, IChunkProvider cp) {
	    if (dimID != 0) return;
	    if (!AstrotweaksModVariables.Overworld_Minerals_Generation) return;
	
	    com.google.common.base.Predicate<IBlockState> match = new com.google.common.base.Predicate<IBlockState>() {
	        @Override
	        public boolean apply(IBlockState state) {
	            return state != null && state.getBlock() == Blocks.STONE;
	        }
	    };
	
	    for (int i = 0; i < 5; i++) {
	        int x = chunkX + random.nextInt(16);
	        int y = random.nextInt(43) + 2;
	        int z = chunkZ + random.nextInt(16);
	
	        new WorldGenMinable(block.getDefaultState(), 8, match).generate(world, random, new BlockPos(x, y, z));
	    }
	}
	

	
	
	public static class BlockCustom extends Block {
		public BlockCustom() {
			super(Material.ROCK);
			setUnlocalizedName("minerals_ore");
			setSoundType(SoundType.STONE);
			setHarvestLevel("pickaxe", 2);
			setHardness(2F);
			setResistance(10F);
			setCreativeTab(TabAstroTweaks.tab);
		}

        private static class DropEntry {
            final String oreDict;
            final int quantity;
            final double weight; // chance

            DropEntry(String oreDict, int quantity, double weight) {
                this.oreDict = oreDict;
                this.quantity = quantity;
                this.weight = weight;
            }
        }

        // list of drops
        private static final List<DropEntry> DROP_LIST = new ArrayList<>();
        static {
			DROP_LIST.add(new DropEntry("oreIron", 		1, 10.0));
			DROP_LIST.add(new DropEntry("oreLead", 		1, 5.0));
			DROP_LIST.add(new DropEntry("oreThorium", 	1, 5.0));
			DROP_LIST.add(new DropEntry("oreCobalt", 	1, 20.0));
			DROP_LIST.add(new DropEntry("oreNickel", 	1, 20.0));
			DROP_LIST.add(new DropEntry("oreTitanium",  1, 30.0));
			DROP_LIST.add(new DropEntry("oreNiobium",   1, 40.0));
			

        }

		@Override
		public void getDrops(NonNullList<ItemStack> drops, IBlockAccess world, BlockPos pos, IBlockState state, int fortune) {
		    // Create list of currently available fields (those in OreDict)
		    List<DropEntry> availableDrops = new ArrayList<>();
		    List<Double> weights = new ArrayList<>();
		    double totalWeight = 0.0;

		    for (DropEntry entry : DROP_LIST) {
		        // Check if at least one item with this oreDict name is registered
		        if (!OreDictionary.getOres(entry.oreDict).isEmpty()) {
		            availableDrops.add(entry);
		            weights.add(entry.weight);
		            totalWeight += entry.weight;
		        }
		    }
		
		    if (availableDrops.isEmpty() || totalWeight <= 0) {
		        return; // no drops
		    }
		
		    Random rand;
		    if (world instanceof World) {
		        rand = ((World) world).rand;
		    } else {
		        rand = new Random();
		    }
		
		    // rolls count for 1 to 2
		    int rolls = rand.nextInt(2) + 1;
		
		    for (int roll = 0; roll < rolls; roll++) {
		        // gen rand number [0, totalWeight)
		        double r = rand.nextDouble() * totalWeight;
		
		        // select item of chance
		        double cumulative = 0.0;
		        for (int i = 0; i < availableDrops.size(); i++) {
		            DropEntry entry = availableDrops.get(i);
		            cumulative += weights.get(i);
		            if (r < cumulative) {
		                // select first element ItemStack of OreDict
		                List<ItemStack> ores = OreDictionary.getOres(entry.oreDict);
		                if (!ores.isEmpty()) {
		                    ItemStack stack = ores.get(0).copy();
		                    stack.setCount(entry.quantity);
		                    drops.add(stack);
		                }
		                break;
		            }
		        }
		    }
		}

		
	}
}
