package astrotweaks.block;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.oredict.OreDictionary;

import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.NonNullList;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.Item;
import net.minecraft.init.Items;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.SoundType;
import net.minecraft.block.Block;

import astrotweaks.creativetab.TabAstroTweaks;
import astrotweaks.ElementsAstrotweaksMod;

import java.util.Random;
import java.util.List;
import java.util.ArrayList;

@ElementsAstrotweaksMod.ModElement.Tag
public class BlockDeepMinerals extends ElementsAstrotweaksMod.ModElement {
    @GameRegistry.ObjectHolder("astrotweaks:deep_minerals")
    public static final Block block = null;

    public BlockDeepMinerals(ElementsAstrotweaksMod instance) {
        super(instance, 696);
    }

    @Override
    public void initElements() {
        elements.blocks.add(() -> new BlockCustom().setRegistryName("deep_minerals"));
        elements.items.add(() -> new ItemBlock(block).setRegistryName(block.getRegistryName()));
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(block), 0,
                new ModelResourceLocation("astrotweaks:deep_minerals", "inventory"));
    }

    public static class BlockCustom extends Block {
        private static class DropEntry {
            final String oreDict;
            final int quantity;
            final double weight; // chance

            DropEntry(String oreDict, int quantity, double weight) {
                this.oreDict = oreDict;
                this.quantity = quantity;
                this.weight = weight;
            }
        }

        // list of drops
        private static final List<DropEntry> DROP_LIST = new ArrayList<>();
        static {
            DROP_LIST.add(new DropEntry("oreCopper", 	2, 10.0));
            DROP_LIST.add(new DropEntry("oreSilver", 	2, 10.0));
            DROP_LIST.add(new DropEntry("oreGold",   	2, 10.0));
			DROP_LIST.add(new DropEntry("oreIron", 		2, 10.0));
			DROP_LIST.add(new DropEntry("oreLapis", 	2, 10.0));
			DROP_LIST.add(new DropEntry("oreRedstone", 	2, 10.0));
			DROP_LIST.add(new DropEntry("oreLead", 		2, 10.0));
			DROP_LIST.add(new DropEntry("oreRuby", 		2, 10.0));
			DROP_LIST.add(new DropEntry("oreTin", 		2, 10.0));
			DROP_LIST.add(new DropEntry("oreUranium", 	2, 10.0));
			DROP_LIST.add(new DropEntry("oreThorium", 	2, 10.0));
			DROP_LIST.add(new DropEntry("oreCobalt", 	2, 10.0));
			DROP_LIST.add(new DropEntry("oreNickel", 	2, 10.0));
			DROP_LIST.add(new DropEntry("orePlatinum", 	2, 10.0));
			DROP_LIST.add(new DropEntry("oreBoron", 	2, 10.0));
			DROP_LIST.add(new DropEntry("oreTitanium",  2, 10.0));
			DROP_LIST.add(new DropEntry("oreNiobium",   2, 10.0));
			DROP_LIST.add(new DropEntry("dustTungsten", 2, 10.0));
			//DROP_LIST.add(new DropEntry("orePalladium", 2, 10.0));
			


        } // chances will be normalized later

        public BlockCustom() {
            super(Material.ROCK);
            setUnlocalizedName("deep_minerals");
            setSoundType(SoundType.STONE);
            setHarvestLevel("pickaxe", 3);
            setHardness(7.5F);
            setResistance(20F);
            //setLightLevel(0F);
            //setLightOpacity(255);
            setCreativeTab(TabAstroTweaks.tab);
        }

        @Override
        public EnumPushReaction getMobilityFlag(IBlockState state) {
            return EnumPushReaction.IGNORE;
        }
		
		@Override
		public void getDrops(NonNullList<ItemStack> drops, IBlockAccess world, BlockPos pos, IBlockState state, int fortune) {
		    // Create list of currently available fields (those in OreDict)
		    List<DropEntry> availableDrops = new ArrayList<>();
		    List<Double> weights = new ArrayList<>();
		    double totalWeight = 0.0;

		    for (DropEntry entry : DROP_LIST) {
		        // Check if at least one item with this oreDict name is registered
		        if (!OreDictionary.getOres(entry.oreDict).isEmpty()) {
		            availableDrops.add(entry);
		            weights.add(entry.weight);
		            totalWeight += entry.weight;
		        }
		    }
		
		    if (availableDrops.isEmpty() || totalWeight <= 0) {
		        return; // no drops
		    }
		
		    Random rand;
		    if (world instanceof World) {
		        rand = ((World) world).rand;
		    } else {
		        rand = new Random();
		    }
		
		    // rolls count for 2 to 4
		    int rolls = rand.nextInt(3) + 2;
		
		    for (int roll = 0; roll < rolls; roll++) {
		        // gen rand number [0, totalWeight)
		        double r = rand.nextDouble() * totalWeight;
		
		        // select item of chance
		        double cumulative = 0.0;
		        for (int i = 0; i < availableDrops.size(); i++) {
		            DropEntry entry = availableDrops.get(i);
		            cumulative += weights.get(i);
		            if (r < cumulative) {
		                // select first element ItemStack of OreDict
		                List<ItemStack> ores = OreDictionary.getOres(entry.oreDict);
		                if (!ores.isEmpty()) {
		                    ItemStack stack = ores.get(0).copy();
		                    stack.setCount(entry.quantity);
		                    drops.add(stack);
		                }
		                break;
		            }
		        }
		    }
		}
    }
}