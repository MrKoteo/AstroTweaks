package astrotweaks.util;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.common.MinecraftForge;

import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import astrotweaks.block.BlockQmBlock;
import astrotweaks.recipe.GavelRecipeRegistry;

import net.minecraftforge.fml.common.Mod.EventHandler;

//import astrotweaks.world.CavernMobModifier;
import astrotweaks.AstrotweaksModVariables;






import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class Handler extends ElementsAstrotweaksMod.ModElement{


	public Handler(ElementsAstrotweaksMod instance) {
		//super(instance, 716);
		super(instance, 500);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GavelRecipeRegistry.initDefaults();

		
	}


	@Override
	public void preInit(FMLPreInitializationEvent event) {
		MinecraftForge.EVENT_BUS.register(this);


	}

	
	@SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        if (event.getState().getBlock() == BlockQmBlock.block) {
            event.setCanceled(true);
        }
    }

    //
}
