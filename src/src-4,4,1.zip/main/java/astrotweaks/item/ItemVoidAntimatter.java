package astrotweaks.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;

import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;

import astrotweaks.procedure.ProcedureAntimatterExplode;

import astrotweaks.creativetab.TabAstroTweaks;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ItemVoidAntimatter extends ElementsAstrotweaksMod.ModElement {
	@GameRegistry.ObjectHolder("astrotweaks:void_antimatter")
	public static final Item block = null;
	public ItemVoidAntimatter(ElementsAstrotweaksMod instance) {
		super(instance, 84);
	}
	// Timer for limit max execs per sec
	private static final Map<Integer, Long> lastUseMs = new java.util.concurrent.ConcurrentHashMap<>();

	

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("astrotweaks:void_antimatter", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(0);
			maxStackSize = 64;
			setUnlocalizedName("void_antimatter");
			setRegistryName("void_antimatter");
			setCreativeTab(TabAstroTweaks.tab);
		}

		//@Override
		//public int getItemEnchantability() {
		//	return 0;
		//}

		//@Override
		//public int getMaxItemUseDuration(ItemStack itemstack) {
		//	return 0;
		//}

		//@Override
		//public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
		//	return 1F;
		//}

		@Override
		public void addInformation(ItemStack itemstack, World world, List<String> tooltip, ITooltipFlag flag) {
  			super.addInformation(itemstack, world, tooltip, flag);
    		tooltip.add(TextFormatting.RED + new TextComponentTranslation("item.void_antimatter.tooltip").getFormattedText());
		}

		@Override
		public void onUpdate(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
		    super.onUpdate(itemstack, world, entity, slot, par5);
		    if (!(entity instanceof EntityLivingBase)) return;
		    if (!((EntityLivingBase) entity).getHeldItemMainhand().equals(itemstack)) return;
		
		    int id = entity.getEntityId();
		    long now = System.currentTimeMillis();
		    Long last = lastUseMs.get(id);
		    if (last != null && now - last < 500) { // < X s - cancel
		        return;
		    }
		    lastUseMs.put(id, now);
		
		    int x = (int) entity.posX;
		    int y = (int) entity.posY;
		    int z = (int) entity.posZ;
		    Map<String, Object> $_dependencies = new HashMap<>();
		    $_dependencies.put("entity", entity);
		    $_dependencies.put("x", x);
		    $_dependencies.put("y", y);
		    $_dependencies.put("z", z);
		    $_dependencies.put("world", world);
		    ProcedureAntimatterExplode.executeProcedure($_dependencies);
		}
	}
}
