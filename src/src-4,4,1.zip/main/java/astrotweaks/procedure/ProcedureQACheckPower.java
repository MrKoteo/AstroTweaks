/*
package astrotweaks.procedure;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.tileentity.TileEntityLockableLoot;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;

import java.util.Map;

import astrotweaks.item.ItemPowerUnit7;
import astrotweaks.item.ItemPowerUnit6;
import astrotweaks.item.ItemPowerUnit5;
import astrotweaks.item.ItemPowerUnit4;
import astrotweaks.item.ItemPowerUnit3;
import astrotweaks.item.ItemPowerUnit2;
import astrotweaks.item.ItemPowerUnit1;
import astrotweaks.item.ItemPowerUnit0;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureQACheckPower extends ElementsAstrotweaksMod.ModElement {
	public ProcedureQACheckPower(ElementsAstrotweaksMod instance) {
		super(instance, 411);
	}

	private static final Item[] LEVELS = new Item[] {
		ItemPowerUnit7.block,
		ItemPowerUnit6.block,
		ItemPowerUnit5.block,
		ItemPowerUnit4.block,
		ItemPowerUnit3.block,
		ItemPowerUnit2.block,
		ItemPowerUnit1.block,
		ItemPowerUnit0.block
	};

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null || dependencies.get("y") == null || dependencies.get("z") == null) {
			System.err.println("Failed to load dependency Coordinates for procedure QACheckPower!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure QACheckPower!");
			return;
		}

		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		BlockPos pos = new BlockPos(x, y, z);

		for (int slot = 0; slot <= 1; slot++) {
			ItemStack current = getItemStack(world, pos, slot);
			if (current.isEmpty()) continue;
			Item curItem = current.getItem();

			for (int i = 0; i < LEVELS.length - 1; i++) {
				if (curItem == new ItemStack(LEVELS[i], 1).getItem()) {
					setItemStack(world, pos, slot, new ItemStack(LEVELS[i + 1], 1));
					return; // only first match
					//break;
				}
			}
		}
	}

	private static ItemStack getItemStack(World world, BlockPos pos, int sltid) {
		TileEntity inv = world.getTileEntity(pos);
		if (inv instanceof TileEntityLockableLoot) {
			return ((TileEntityLockableLoot) inv).getStackInSlot(sltid);
		}
		return ItemStack.EMPTY;
	}

	private static void setItemStack(World world, BlockPos pos, int sltid, ItemStack stack) {
		TileEntity inv = world.getTileEntity(pos);
		if (inv instanceof TileEntityLockableLoot) {
			stack.setCount(1);
			((TileEntityLockableLoot) inv).setInventorySlotContents(sltid, stack);
		}
	}
}

*/
