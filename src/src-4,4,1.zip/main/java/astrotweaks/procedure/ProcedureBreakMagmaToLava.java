package astrotweaks.procedure;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.init.Blocks;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.Entity;

import java.util.Map;
import astrotweaks.world.DepthsDim;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureBreakMagmaToLava extends ElementsAstrotweaksMod.ModElement {
	private static final int CAVERN_DIM_ID = DepthsDim.DIMID;

	public ProcedureBreakMagmaToLava(ElementsAstrotweaksMod instance) {
		super(instance, 698);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		String[] keys = {"x", "y", "z", "world"};
		for (String key : keys) {
		    if (dependencies.get(key) == null) {
		        System.err.println("Failed to load dependency " + key + " for proc BreakMagmaToLava!");
		        return;
		    }
		}

		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		double chance = 0;
		chance = (double) Math.random();
		if (((chance) < 0.2)) {
			world.setBlockState(new BlockPos((int) x, (int) y, (int) z), Blocks.LAVA.getDefaultState(), 3);
			if (((chance) < 0.1)) {
				if (!world.isRemote) {
					Entity entityToSpawn = new EntityMagmaCube(world);
					if (entityToSpawn != null) {
						entityToSpawn.setLocationAndAngles((x + 0.5), (y + 0.5), (z + 0.5), world.rand.nextFloat() * 360F, 0.0F);
						world.spawnEntity(entityToSpawn);
					}
				}
			}
		}
	}
}

