package astrotweaks.procedure;

import net.minecraft.world.WorldServer;
import net.minecraft.world.Teleporter;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.server.MinecraftServer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.FMLCommonHandler;

import java.util.Map;
import java.util.HashMap;

import astrotweaks.world.DepthsDim;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureSwitchDimProc extends ElementsAstrotweaksMod.ModElement {
	public ProcedureSwitchDimProc(ElementsAstrotweaksMod instance) {super(instance, 582);}

	public static void executeProcedure(Map<String, Object> dependencies) {
        if (dependencies.get("entity") == null || dependencies.get("cmdparams") == null) {
            System.err.println("Failed to exec for proc SwitchDimProc!");return;
        }

	    @SuppressWarnings("unchecked")
	    HashMap<String, String> cmdparams = (HashMap<String, String>) dependencies.get("cmdparams");
			
	    Entity entity = (Entity) dependencies.get("entity");
	    EntityPlayerMP executor = null;
	    if (entity instanceof EntityPlayerMP) {
	        executor = (EntityPlayerMP) entity;
	    }

		if (executor != null && executor.world.isRemote) return; // server side only
	
	    MinecraftServer mcServer = null;
	    if (executor != null) mcServer = executor.getServer();
	    if (mcServer == null) mcServer = FMLCommonHandler.instance().getMinecraftServerInstance();
	    if (mcServer == null) {
		    if (executor != null) executor.sendMessage(new TextComponentString("Server instance not found."));
		    else System.out.println("Server instance not found.");
		    return;
		}

		String dimParam = getParam(cmdparams, 0);
		String playerNameParam = getParam(cmdparams, 1);
		String xParam = getParam(cmdparams, 2);
		String yParam = getParam(cmdparams, 3);
		String zParam = getParam(cmdparams, 4);

		if ("@s".equals(playerNameParam)) playerNameParam = null;

		// get target player
	    EntityPlayerMP targetPlayer = null;
	    if (playerNameParam != null && !playerNameParam.isEmpty()) {
	        targetPlayer = mcServer.getPlayerList().getPlayerByUsername(playerNameParam);
	        if (targetPlayer == null) {
	            String msg = "Player not found: " + playerNameParam;
	            if (executor != null) executor.sendMessage(new TextComponentString(msg));
	            else System.out.println(msg);
	            return;
	        }
	    } else {
	        if (executor != null) targetPlayer = executor;
	        else {
	            System.out.println("You must specify a player name when running from console.");
	            return;
	        }
	    }
	
	    // ----------------------------------------------
	    // NEW: check for tp to PlayerName
	    // ----------------------------------------------
	    boolean teleportToPlayerMode = false;
	    String sourcePlayerName = null;
	    if (xParam != null && !xParam.isEmpty() && yParam.isEmpty() && zParam.isEmpty() && !isCoordinateToken(xParam)) {
	        // The third argument doesn't look like a coordinate, and the fourth and fifth are empty, which means it's the name of another player.
	        sourcePlayerName = xParam;
	        teleportToPlayerMode = true;
	    } else if (xParam != null && !xParam.isEmpty() && !isCoordinateToken(xParam)) {
	        // xParam is not a coordinate, but yParam or zParam are not empty - syntax error
	        String msg = "Invalid syntax: expected coordinates or player name.";
	        if (executor != null) executor.sendMessage(new TextComponentString(msg));
	        else System.out.println(msg);
	        return;
	    }
	    
	
	    Integer targetDim = null;
	    boolean hasCoords = false; // parse coords
	    double tx = 0, ty = 0, tz = 0;
	
	    if (teleportToPlayerMode) {
	        // tp to Player
	        EntityPlayerMP sourcePlayer = mcServer.getPlayerList().getPlayerByUsername(sourcePlayerName);
	        if (sourcePlayer == null) {
	            String msg = "Source player not found: " + sourcePlayerName;
	            if (executor != null) executor.sendMessage(new TextComponentString(msg));
	            else System.out.println(msg);
	            return;
	        }
	        // Use DIM and Coords of sourcePlayer
	        targetDim = sourcePlayer.dimension;
	        tx = sourcePlayer.posX;
	        ty = sourcePlayer.posY;
	        tz = sourcePlayer.posZ;
	        hasCoords = true;
	        // optional message
	        String info = "Teleporting to " + sourcePlayerName + " at dim " + targetDim;
	        if (executor != null) executor.sendMessage(new TextComponentString(info));
	        
	    } else {
	        // Simple mode: parse DIM and Coords
	        targetDim = resolveDimensionId(dimParam);
	        if (targetDim == null) {
	            String msg = "Unknown dimension id: " + dimParam;
	            if (executor != null) executor.sendMessage(new TextComponentString(msg));
	            else System.out.println(msg);
	            return;
	        }
	
	        // parse coords
	        try {
	            if (xParam != null && !xParam.isEmpty() &&
	                yParam != null && !yParam.isEmpty() &&
	                zParam != null && !zParam.isEmpty()) {
	                tx = parseCoord(xParam, targetPlayer.posX, false);
	                ty = parseCoord(yParam, targetPlayer.posY, true);
	                tz = parseCoord(zParam, targetPlayer.posZ, false);
	                hasCoords = true;
	            }
	        } catch (NumberFormatException e) {
	            String msg = "Invalid coordinates.";
	            if (executor != null) executor.sendMessage(new TextComponentString(msg));
	            else System.out.println(msg);
	            return;
	        }
	    }

	
	    // save last pos
	    targetPlayer.getEntityData().setDouble("lastDimPosX", targetPlayer.posX);
	    targetPlayer.getEntityData().setDouble("lastDimPosY", targetPlayer.posY);
	    targetPlayer.getEntityData().setDouble("lastDimPosZ", targetPlayer.posZ);
	    targetPlayer.getEntityData().setInteger("lastDimId", targetPlayer.dimension);
	    // use transferPlayerToDimension - it will load the world automatically
	    mcServer.getPlayerList().transferPlayerToDimension(targetPlayer, targetDim, new TeleporterDirectWrapper(targetDim, mcServer));

	    // after the transfer we will receive WorldServer via the server (guaranteed loaded)
	    WorldServer targetWorld = mcServer.getWorld(targetDim);
	    if (targetWorld == null) {
	        String msg = "Failed to load target world.";
	        if (targetPlayer != null) targetPlayer.sendMessage(new TextComponentString(msg));
	        else System.out.println(msg);
	        return;
	    }
		if (hasCoords) { // set pos (teleportTo of EntityPlayerMP)
		    targetPlayer.setPositionAndUpdate(tx, ty, tz);
		}
	
		String msg = "Teleported player " + targetPlayer.getName() + " to dimension " + targetDim + (hasCoords ? (" at " + tx + ", " + ty + ", " + tz) : ".");
	    if (executor != null) executor.sendMessage(new TextComponentString(msg));
	    else System.out.println(msg);


	}

    private static boolean isCoordinateToken(String token) {
	    if (token == null || token.isEmpty()) return false;
	    char first = token.charAt(0);
	    // Allow: tilda, digits, minus, dot
	    return first == '~' || first == '-' || first == '.' || Character.isDigit(first);
	}
	

    
	// get param for index
	private static String getParam(HashMap<String, String> cmdparams, int index) {
		if (cmdparams == null) {return "";}
		String key = Integer.toString(index);
		String val = cmdparams.get(key);
		return val != null ? val : "";
	}

	private static double parseCoord(String token, double base, boolean isY) throws NumberFormatException {
	    token = token.trim();
	    if (token.startsWith("~")) {
	        String rest = token.length() == 1 ? "" : token.substring(1).trim();
	        if (rest.isEmpty()) return base;                // "~" -> base (no shift)
	        return base + Double.parseDouble(rest);        // "~1" -> base+1 ; "~1.5" -> base+1.5
	    } else {
	        // absolute coords
	        if (token.contains(".") || token.contains(",")) {
	            return Double.parseDouble(token.replace(',', '.'));
	        } else {
	            // of center of block
	            if (!isY) {return Double.parseDouble(token) + 0.5; }
	            else {return Double.parseDouble(token); }
	        }
	    }
	}
	// Dimension ID resolution: support for aliases (e.g. "-6000" or "-2" ->
	private static Integer resolveDimensionId(String raw) {
		if (raw == null || raw.isEmpty())
			return null;
		raw = raw.trim();
		// specials
		if (raw.equals("-6000") || raw.equals("-2"))
			return DepthsDim.DIMID;
		if (raw.equals("cavern"))
			return DepthsDim.DIMID;
		try {
			return Integer.parseInt(raw);
		} catch (NumberFormatException e) {
			return null;
		}
	}
	private static class TeleporterDirectWrapper extends Teleporter {
		private final int dim;
		private final MinecraftServer server;
		public TeleporterDirectWrapper(int dimension, MinecraftServer server) {
			// use the world for the current server dimension (the Teleporter constructor
			// requires a WorldServer; we'll take the player's world before the transition)
			super(server.getWorld(0) != null ? server.getWorld(0) : server.getWorld(dimension));
			this.dim = dimension;
			this.server = server;
		}
		@Override
		public void placeInPortal(Entity entity, float yawRotation) {}
		@Override
		public boolean placeInExistingPortal(Entity entity, float yawRotation) {return true;}
		@Override
		public boolean makePortal(Entity entity) {return true;}
	}
}
