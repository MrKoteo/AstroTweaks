package astrotweaks.procedure;

import net.minecraft.world.World;
import java.util.Map;
import java.util.HashMap;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureMTRedstoneOn extends ElementsAstrotweaksMod.ModElement {
	public ProcedureMTRedstoneOn(ElementsAstrotweaksMod instance) {
		super(instance, 375);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		String[] keys = {"x", "y", "z", "world"};
		for (String key : keys) {
		    if (dependencies.get(key) == null) {
		        System.err.println("Failed to load dependency " + key + " for proc MTRedstoneOn!");
		        return;
		    }
		}

		int x= (int) dependencies.get("x");
		int y= (int) dependencies.get("y");
		int z= (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		{
			Map<String, Object> $_dependencies = new HashMap<>();
			$_dependencies.put("world", world);
			$_dependencies.put("x", x);
			$_dependencies.put("y", y);
			$_dependencies.put("z", z);
			ProcedureMTConvert.executeProcedure($_dependencies);
		}
	}
}