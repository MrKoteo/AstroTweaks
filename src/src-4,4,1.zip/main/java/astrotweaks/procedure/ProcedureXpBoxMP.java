package astrotweaks.procedure;

import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import java.util.Map;

import java.lang.reflect.Type;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureXpBoxMP extends ElementsAstrotweaksMod.ModElement {
	public ProcedureXpBoxMP(ElementsAstrotweaksMod instance) {
		super(instance, 632);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure XpBoxMP!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			System.err.println("Failed to load dependency itemstack for procedure XpBoxMP!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		double XpAmount = 0;
		boolean Type = false;
		XpAmount = (double) ((itemstack).hasTagCompound() ? (itemstack).getTagCompound().getDouble("xp") : -1);
		Type = (boolean) ((false) || ((itemstack).hasTagCompound() && (itemstack).getTagCompound().getBoolean("levels")));
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).inventory.clearMatchingItems((itemstack).getItem(), -1, (int) 1, null);
		if ((Type)) {
			if (entity instanceof EntityPlayer)
				((EntityPlayer) entity).addExperienceLevel((int) (XpAmount));
		} else {
			if (entity instanceof EntityPlayer)
				((EntityPlayer) entity).addExperience((int) (XpAmount));
		}
	}
}
