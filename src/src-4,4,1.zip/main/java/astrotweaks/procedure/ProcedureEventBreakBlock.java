package astrotweaks.procedure;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;
import net.minecraft.init.Blocks;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import java.util.Map;
import java.util.HashMap;

import astrotweaks.item.ItemPlantFiber;
import astrotweaks.item.ItemCordageVine;
import astrotweaks.procedure.ProcedureBreakMagmaToLava;
import astrotweaks.world.DepthsDim;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureEventBreakBlock extends ElementsAstrotweaksMod.ModElement {
    private static final int CAVERN_DIM_ID = DepthsDim.DIMID;
	
	public ProcedureEventBreakBlock(ElementsAstrotweaksMod instance) {
		super(instance, 340);
	}

	private static void spawnItem(World world, int x, int y, int z, ItemStack stack) {
		if (world == null || stack == null || world.isRemote) return;
		EntityItem entityToSpawn = new EntityItem(world, x + 0.5, y + 0.5, z + 0.5, stack);
		entityToSpawn.setPickupDelay(10);
		world.spawnEntity(entityToSpawn);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		String[] keys = {"x", "y", "z", "world", "entity"};
		for (String key : keys) {
		    if (dependencies.get(key) == null) {
		        System.err.println("Failed to load dependency " + key + " for proc DeleteXArea!");
		        return;
		    }
		}

		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		final double rng1 = Math.random();
		double RANGNUM = 0;

		ItemStack held = (entity instanceof EntityLivingBase) ? ((EntityLivingBase) entity).getHeldItemMainhand() : ItemStack.EMPTY;
		boolean notShears = !(held.getItem() == new ItemStack(Items.SHEARS, 1).getItem());
		net.minecraft.block.Block block = world.getBlockState(new BlockPos(x, y, z)).getBlock();

		int dim;
		if (entity instanceof EntityLivingBase) {
		    dim = ((EntityLivingBase) entity).dimension; // or ((Entity)entity).world.provider.getDimension()
		} else {
		    dim = world.provider.getDimension();
		}

		// tall grass / double plant (meta checks preserved)
		boolean isTallGrassVariant = block == Blocks.TALLGRASS.getStateFromMeta(1).getBlock() || block == Blocks.DOUBLE_PLANT.getStateFromMeta(2).getBlock();

		if (isTallGrassVariant && notShears) {
			if (rng1 < 0.14) {
				spawnItem(world, x, y, z, new ItemStack(ItemPlantFiber.block, 1));
			}
			if (Math.random() < 0.51 && rng1 < 0.02) {
				RANGNUM = Math.random();
				if (RANGNUM < 0.25) {
					spawnItem(world, x, y, z, new ItemStack(Items.POISONOUS_POTATO, 1));
				} else if (RANGNUM < 0.39) {
					spawnItem(world, x, y, z, new ItemStack(Items.CARROT, 1));
				} else if (RANGNUM < 0.52) {
					spawnItem(world, x, y, z, new ItemStack(Items.POTATO, 1));
				} else if (RANGNUM < 0.77) {
					spawnItem(world, x, y, z, new ItemStack(Items.WHEAT, 1));
				} else if (RANGNUM < 0.86) {
					spawnItem(world, x, y, z, new ItemStack(Items.BEETROOT, 1));
				} else if (RANGNUM < 0.93) {
					spawnItem(world, x, y, z, new ItemStack(Blocks.BROWN_MUSHROOM, 1));
				} else if (RANGNUM < 0.98) {
					spawnItem(world, x, y, z, new ItemStack(Blocks.RED_MUSHROOM, 1));
				} else {
					spawnItem(world, x, y, z, new ItemStack(Blocks.TALLGRASS, 1, 1));
				}
			}
		} else if (block == Blocks.VINE.getDefaultState().getBlock() && notShears) {
			if (Math.random() < 0.25) {
				spawnItem(world, x, y, z, new ItemStack(ItemCordageVine.block, 1));
			}
		} else if (dim == CAVERN_DIM_ID && block == Blocks.MAGMA.getDefaultState().getBlock()) {
			Map<String, Object> $_dependencies = new HashMap<>();
			$_dependencies.put("world", world);
			$_dependencies.put("x", x);
			$_dependencies.put("y", y);
			$_dependencies.put("z", z);
			ProcedureBreakMagmaToLava.executeProcedure($_dependencies);
		}
	}

	@SubscribeEvent
	public void onBlockBreak(BlockEvent.BreakEvent event) {
		Entity entity = event.getPlayer();
		java.util.HashMap<String, Object> dependencies = new java.util.HashMap<>();
		dependencies.put("xpAmount", event.getExpToDrop());
		dependencies.put("x", (int) event.getPos().getX());
		dependencies.put("y", (int) event.getPos().getY());
		dependencies.put("z", (int) event.getPos().getZ());
		dependencies.put("px", (int) entity.posX);
		dependencies.put("py", (int) entity.posY);
		dependencies.put("pz", (int) entity.posZ);
		dependencies.put("world", event.getWorld());
		dependencies.put("entity", entity);
		dependencies.put("event", event);
		this.executeProcedure(dependencies);
	}

	@Override
	public void preInit(FMLPreInitializationEvent event) {
		MinecraftForge.EVENT_BUS.register(this);
	}
}
