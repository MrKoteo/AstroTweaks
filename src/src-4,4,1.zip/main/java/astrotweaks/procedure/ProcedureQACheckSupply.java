/*
package astrotweaks.procedure;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.tileentity.TileEntityLockableLoot;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;

import java.util.Map;
import java.util.Arrays;
import java.util.List;

import astrotweaks.item.ItemPowerUnit7;
import astrotweaks.item.ItemPowerUnit6;
import astrotweaks.item.ItemPowerUnit5;
import astrotweaks.item.ItemPowerUnit4;
import astrotweaks.item.ItemPowerUnit3;
import astrotweaks.item.ItemPowerUnit2;
import astrotweaks.item.ItemPowerUnit1;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureQACheckSupply extends ElementsAstrotweaksMod.ModElement {
	public ProcedureQACheckSupply(ElementsAstrotweaksMod instance) {
		super(instance, 513);
	}

	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null || dependencies.get("y") == null || dependencies.get("z") == null) {
			System.err.println("Failed to load dependency Coordinates for procedure QACheckSupply!");
			return false;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure QACheckSupply!");
			return false;
		}

		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");

		List<Item> validItems = Arrays.asList(
		    (Item) ItemPowerUnit7.block,
		    (Item) ItemPowerUnit6.block,
		    (Item) ItemPowerUnit5.block,
		    (Item) ItemPowerUnit4.block,
		    (Item) ItemPowerUnit3.block,
		    (Item) ItemPowerUnit2.block,
		    (Item) ItemPowerUnit1.block
		);

		for (int slot = 0; slot <= 1; slot++) {
		    ItemStack stack = getItemStack(world, new BlockPos(x, y, z), slot);
		    if (!stack.isEmpty()) {
		        Item item = stack.getItem();
		        for (Item valid : validItems) {
		            if (item == new ItemStack(valid, 1).getItem()) {
		                return true;
		            }
		        }
		    }
		}
		return false;
	}

	private static ItemStack getItemStack(World world, BlockPos pos, int sltid) {
		TileEntity inv = world.getTileEntity(pos);
		if (inv instanceof TileEntityLockableLoot) {
			return ((TileEntityLockableLoot) inv).getStackInSlot(sltid);
		}
		return ItemStack.EMPTY;
	}
}

*/
