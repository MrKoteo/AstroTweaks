package astrotweaks.procedure;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import java.util.Map;
import java.util.HashMap;

import astrotweaks.item.ItemXpBoxU;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureATCP extends ElementsAstrotweaksMod.ModElement {
	public ProcedureATCP(ElementsAstrotweaksMod instance) {
		super(instance, 634);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure ATCP!");
			return;
		}
		if (dependencies.get("cmdparams") == null) {
			System.err.println("Failed to load dependency cmdparams for procedure ATCP!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		HashMap cmdparams = (HashMap) dependencies.get("cmdparams");
		boolean xpb_mode = false;
		double xpb_count = 0;
		ItemStack CurrentItem = ItemStack.EMPTY;
		xpb_count = (double) new Object() {
			int convert(String s) {
				try {
					return Integer.parseInt(s.trim());
				} catch (Exception e) {
				}
				return 0;
			}
		}.convert((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("1");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText()));
		xpb_mode = (boolean) ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("2");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("True")) || ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("2");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("1")) || (((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("2");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("true"))));
		CurrentItem = new ItemStack(ItemXpBoxU.block, (int) (1));
		{
			ItemStack _stack = (CurrentItem);
			if (!_stack.hasTagCompound())
				_stack.setTagCompound(new NBTTagCompound());
			_stack.getTagCompound().setDouble("xp", (xpb_count));
		}
		{
			ItemStack _stack = (CurrentItem);
			if (!_stack.hasTagCompound())
				_stack.setTagCompound(new NBTTagCompound());
			_stack.getTagCompound().setBoolean("levels", (xpb_mode));
		}
		if (entity instanceof EntityPlayer) {
			ItemStack _setstack = (CurrentItem);
			_setstack.setCount(1);
			ItemHandlerHelper.giveItemToPlayer(((EntityPlayer) entity), _setstack);
		}
	}
}
